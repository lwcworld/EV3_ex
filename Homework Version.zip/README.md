###### useful command
- getAvailableComPort() : show available comport
- fclose('all') : close all the ComPorts